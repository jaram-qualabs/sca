
//array con path de los json a consultar
var users = [];
for (let i = 0; i < 20; i++) {
    let path = "./u" + i + ".json";
    users.push(path);  
}


//objeto resultado (salida)
const resultado = {
    "auth_module" : {
                    "authn.provider_1":[],
                    "authn.provider_2":[],
                    "authn.provider_3":[],
                    "authn.provider_4":[]
                    },
    "content_module" :{
                    "authz.provider_1":[],
                    "authz.provider_2":[],
                    "authz.provider_3":[],
                    "authz.provider_4":[]
                    }
}

//funcion que crea archivo .json con resultado
function exportResult(result){
    let resStr = JSON.stringify(result);
    let dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(resStr);
    let fileName = "resultado.json";
    let linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', fileName);
    linkElement.click();

}

//recorre usuarios y asigna a los modulos que utiliza, exporta resultado
async function filter(users){
    try{
        for (let i = 0; i < users.length; i++) {
            const response = await fetch(users[i]);
            const resJson = await response.json();
            if(resJson.provider.content_module == 'authz.provider_1'){
                resultado.content_module["authz.provider_1"].push(users[i]);
            }else if(resJson.provider.content_module == 'authz.provider_2'){
                resultado.content_module["authz.provider_2"].push(users[i]);
            }else if(resJson.provider.content_module == 'authz.provider_3'){
                resultado.content_module["authz.provider_3"].push(users[i]);
            }else if(resJson.provider.content_module == 'authz.provider_4'){
                resultado.content_module["authz.provider_4"].push(users[i]);
            };

            if(resJson.provider.auth_module == 'authn.provider_1'){
                resultado.auth_module["authn.provider_1"].push(users[i]);
            }else if(resJson.provider.auth_module == 'authn.provider_2'){
                resultado.auth_module["authn.provider_2"].push(users[i]);
            }else if(resJson.provider.auth_module == 'authn.provider_3'){
                resultado.auth_module["authn.provider_3"].push(users[i]);
            }else if(resJson.provider.auth_module == 'authn.provider_4'){
                resultado.auth_module["authn.provider_4"].push(users[i]);
            };
        }
    }
    catch(err){
        console.log('fetch faild',err);
    };
    exportResult(resultado); 
};

filter(users);




