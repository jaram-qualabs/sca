import React from 'react';
import  {Bar1} from './Bar1';
// import { getMockedData } from './utils/mocked-data';

export const App = () => {
  return (
    <div className='main'>
      <Bar1 />
      {/* <getMockedData /> */}
    </div>
  )
}