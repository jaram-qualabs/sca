import React from 'react';
import { Bar2 } from './Bar2';

export const Screen = (props) => {
  
  const parent = props.parent;


  return(
    parent ? 
      <div className='screen'>
        <Bar2 parent={parent}/>
      </div>
    :
      <div className='screen'>
        <h3>Click Content or Auth button</h3>
      </div>

  )
}

