import React from 'react';
import { ButtonUnable } from './ButtonUnable';
import { ButtonUI} from './ButtonUI';

//Debería de recibir de mockData los usuarios de cada modulo y pasarlo en cada action

export const Content = (props) => {
    
    const cmodulo1=["./u4.json","./u14.json"];
    const cmodulo2=["./u8.json","./u9.json","./u13.json","./u15.json","./u16.json","./u17.json"];
    const cmodulo3=["./u2.json","./u3.json","./u5.json","./u10.json","./u11.json","./u18.json"];
    const cmodulo4=["./u0.json","./u1.json","./u6.json","./u7.json","./u12.json","./u19.json"];
    const amodulo1=["./u3.json","./u4.json","./u17.json","./u19.json"];
    const amodulo2=["./u1.json","./u6.json","./u8.json","./u10.json","./u13.json","./u14.json","./u16.json","./u18.json"];
    const amodulo3=["./u0.json","./u7.json","./u11.json","./u12.json","./u15.json"];
    const amodulo4=["./u2.json","./u5.json","./u9.json"];
    const modulo = props.modulo;
    const parent = props.parent;
    var array=[];

    if(parent == "CONTENT"){
      if(modulo == "MODULE 1"){
        array = cmodulo1;
      }else if (modulo == "MODULE 2"){
        array = cmodulo2;
      }else if (modulo == "MODULE 3"){
        array = cmodulo3;
      }else if (modulo == "MODULE 4"){
        array = cmodulo4;
      }
    }else if(parent == "AUTH"){
      if(modulo == "MODULE 1"){
        array = amodulo1;
      }else if (modulo == "MODULE 2"){
        array = amodulo2;
      }else if (modulo == "MODULE 3"){
        array = amodulo3;
      }else if (modulo == "MODULE 4"){
        array = amodulo4;
      }
    }

  return (
    
    <div className='content'>
      {
        modulo ?
        <h3>Number of users in {modulo} in {parent}</h3>
        :
        <h3>Select a module {modulo}</h3>

      }
      <div className='lista'> 
        {
          array.map((e) => {
              return (
                <button className='usuLista'>
                {e}
              </button>
              );
              })

        }   
      </div>
      
      {/* Falta acciones */}
      <div className='botones'> 
          <ButtonUI action="Delete" style={{backgroundColor:"red"}}/>
          <ButtonUI action="Advice" style={{backgroundColor:"yellow"}}/>
          <ButtonUI action="Create" style={{backgroundColor:"pink"}}/>
          <ButtonUI action="Submit" style={{backgroundColor:"aqua"}}/>
      </div>
        
    </div>
  )
}