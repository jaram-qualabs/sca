import React from 'react';

//Botones de abajo que permiten interaccion con la data
//Faltan iconos 
export const ButtonUI = ({action, style}) => {
  return (
    <button className='botonesUI' style={style} >
        {action}
    </button>
  )
}