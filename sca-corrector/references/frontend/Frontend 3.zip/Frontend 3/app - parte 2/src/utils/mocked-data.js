import input from '../resultado.json';


const info="";

export const getMockedData = () => {
        fetch(input
        ,{
        headers : { 
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        }
        )
        .then(function(response){
            console.log(response)
            return response.json();
            
        })
        .then(function(myJson) {
            console.log(myJson);
            info = myJson;
        });
    }


