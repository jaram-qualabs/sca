import React, {useState} from 'react';
import { Screen } from './Screen';



export const Bar1 = () => {
  const titulo =["CONTENT", "AUTH"]; //deberia de traerlo del mockData
  const [show, setShow] = useState("");

  function displayScreen(a){
    a == "CONTENT" ? 
       (setShow("CONTENT")) 
       : 
       (setShow("AUTH")) 
    } 

  if (show === "CONTENT"){
    document.getElementById(show).style.backgroundColor='purple';
    document.getElementById("AUTH").style.backgroundColor='rgb(165, 52, 156)';
  }else if(show === "AUTH"){
    document.getElementById(show).style.backgroundColor='purple';
    document.getElementById("CONTENT").style.backgroundColor='rgb(165, 52, 156)';
  }

  return (
    <>
    
      <div className='bar'>   
        {
          titulo.map((e) => {
              return (
                <button id={e} className='buttonAction' onClick={()=>(displayScreen(e))}>
                  {e}
                </button>
              );
              })

        }        
      </div>
      <div>
          <Screen parent={show}/>
      </div>
    </>
    
  )
}