import React, { useState } from 'react';
import { Content } from './Content';


export const Bar2 = (props) => {
  const titulo =["MODULE 1","MODULE 2","MODULE 3","MODULE 4"]; // deberia de traerlo desde el mockData 
  const [modulo, setModulo] = useState("");
  const parent = props.parent;

  function displayContent(a){
    if(a == titulo[0]){
      (setModulo(a))  
    } else if(a == titulo[1]){
      (setModulo(a)) 
    }else if(a == titulo[2]){
      (setModulo(a)) 
    }else if(a == titulo[3]){
      (setModulo(a)) 
    }else{
      (alert("Error")) 
    };
  };  
  
  //Cambio de color el button segun click
  if (modulo === "MODULE 1"){
    document.getElementById("MODULE 1").style.backgroundColor='purple';
    document.getElementById("MODULE 2").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 3").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 4").style.backgroundColor='rgb(165, 52, 156)';
  }else if(modulo === "MODULE 2"){
    document.getElementById("MODULE 1").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 2").style.backgroundColor='purple';
    document.getElementById("MODULE 3").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 4").style.backgroundColor='rgb(165, 52, 156)';
  }else if(modulo === "MODULE 3"){
    document.getElementById("MODULE 1").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 2").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 3").style.backgroundColor='purple';
    document.getElementById("MODULE 4").style.backgroundColor='rgb(165, 52, 156)';
  }else if(modulo === "MODULE 4"){
    document.getElementById("MODULE 1").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 2").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 3").style.backgroundColor='rgb(165, 52, 156)';
    document.getElementById("MODULE 4").style.backgroundColor='purple';
  }
       
    
  return (
    <>
      <div className='bar'>   
          {
              titulo.map((e) => {
                  return (
                    <button id={e} className='buttonAction' onClick={()=>(displayContent(e))}>
                    {e}
                  </button>
                  );
                  })

              }        
      </div>
      <div className='contenido'>
              <Content parent={parent} modulo={modulo} />
      </div>
    </>
    
  )
}