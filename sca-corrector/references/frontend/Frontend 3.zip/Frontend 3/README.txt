﻿PARTE A:


Instrucciones: 


1- Abrir la carpeta files-parte 1 en el Visual Studio Code.
2- Correr el código en el servidor local clickeando en el botón Go Live en la esquina inferior derecha. 
3- Se abrirá un navegador y automáticamente se descargará un archivo .json con la salida.




PARTE B:


Realizado con React.


Para realizar un build debe correr desde la consola el comando “npm run build”. Se creara una carpeta /build que contendrá la compilación de la aplicación.


Comentarios:
No pude instalar Sass por lo que utilicé css normal.