import os
import json

result = { "auth_module": {}, "content_module": {} }

for filename in os.listdir("files"):
    f = open("./files/" + filename)
    data = json.load(f)
    for key, value in data["provider"].items():
        if (not value in result[key]):
            result[key][value] = []
        result[key][value].append(filename)
    f.close()
final_json = json.dumps(result)
print(final_json)
