# Documentation of the solutions!

Hey there! Here is the explanations on how I came up with the two solutions for the Qualabs Test, hope you enjoy it!


# Part 1

## How to run?

To run this file, on your terminal go to the folder where the part1.py file is and write **python3 part1.py**. Keep in mind that you need to have python3 installed.

## How the solution was built?

### Open a file using Python

Firstly what I did was to try to open one of the .json files of the 'pruebatecnica' folder by code.
Using the Python's built in package:json I handled to open one of the JSON files. 

    import  json
    f = open("./files/u17.json")
    data = json.load(f)
    print(data["name"])
    f.close()
As you can see we use the method *open* to open the file(of course), and later we use the method *load* to turn the JSON into a Python type(deserialization) so we can handle that information.
After that I printed the name and I knew how to access to the data because the website where I took all the information about json had this very useful table.
https://www.geeksforgeeks.org/read-json-file-using-python/ 
The one that says JSON object -> Python object.

### Reading all the files of a folder

Okay , now since we know how to open a file and do fancy stuff with it, we just need all the file names we are going to read.
Luckily, there is another built in package called os, that allows me to check for the file names inside the folder.
In particular using the method listdir("name_of_the_folder") I can get the name of all the files:

    import  os
    for  filename  in  os.listdir("files"):

### Handling the data
Now our main goal is going to be to check all the files only once, which is more than possible using dictionaries.
Now let's handle our result variable(which is going to be a dictonary).

    import  os
    import  json
    result = { "auth_module": {}, "content_module": {} }
    for  filename  in  os.listdir("files"):
	    f = open("./files/" + filename) 
	    data = json.load(f)
	    for  key, value  in  data["provider"].items():
		    if (not  value  in  result[key]):
			    result[key][value] = []
			result[key][value].append(filename)
	    f.close()
    print(result)
Firstly we declare our result dictonary with the two main keys asked in the solution *auth_module* and *content_module* ,after that we are going to iterate through every single file checking for the key and the value.
**Why are we using this kind of for iteration?**
Because we also need the keys, to make the structure that we need for the solution.
Finally we check if that specific key is defined in our result[value] dictionary, and if it isn't we define an array, and aftewards we append the filename on it.

#### Important details about this solution:
Since I have limited time to build this solution I assumed one thing about the Python programming language and it's running time and that is: 

    value in result[key] Is O(1) 

# Part 2(Part C)

## How to run?

To run this file, on your terminal write **npm i** and afterwards **npm run start**. After doing that, go to your browser and type **localhost:3000**.

## How the solution was built?
To build this solution firstly I had to learn the basics of react, the following video turned out to be very useful as a starter's guide: https://www.youtube.com/watch?v=w7ejDZ8SWv8 .
After watching part of the tutorial and making a couple tests, I identified the components the solution was based.
These are 4 <img width="680" alt="Screen Shot 2022-01-16 at 7 42 09 PM" src="https://user-images.githubusercontent.com/39934588/149681068-bc71ab9a-ed5a-4dd1-8390-a1c56452d93e.png">
*Button*: Since we want all buttons to look pretty much the same.
*Header*: Contains a list of buttons alligned horizontally.
*ActionButtons*: Buttonson the bottom right corner.
*Frame*: Wraps all the previous mentioned components and also has a list of buttons with the users.
*UsersButtons*: Lists user buttons.
### The design
After idenfitying every single component, I started building the solution, using only harcoded data.
To style the components I chose to use only classes on CSS and avoid using classes AND ids.

### The data 
In order to use the data from problem1 I copied what the part1.py printed in the console and I pasted it as a new file called data.json on the src folder.
After that to get the data into the actual js file I 

### The states
To handle that every single time I push a button of the header something happens in the Frame, I had to build to state variables:

    const [module, setModule] = useState("auth_module")
    const [provider,setProvider] = useState("authn.provider_3")
module refers to the selected module and provider refers to the selected provider.
Notice that I added some default values when the app runs for the first time.    
    
So every single time I hit one of the buttons of the header the functions: setModule or setProvider are called and the whole screen gets reloaded with the new data.

## How to make a build?
Inside the partc folder run this command:
    npm run build

