import { useState } from "react"
import { Header } from "./Header"
import { UsersButtons } from "./UsersButtons"
import { ActionButtons } from "./ActionButtons"
var data = require('../data.json')

export const Frame = () => {
    const [module, setModule] = useState("auth_module")
    const [provider,setProvider] = useState("authn.provider_3")
    var modules = Object.keys(data)
    var providers = Object.keys(data[module])
    var users = data[module][provider] ?? data[module][providers[0]]
    return (
        <div className="container">
            <Header 
                buttons_color="purple" 
                selected={module} 
                elements={modules} 
                action={(my_module)=> {setModule(my_module);}}
            />
            <div className="container">
                <Header 
                    buttons_color="purple" 
                    selected={provider} 
                    elements={providers} 
                    action= {(my_provider)=> setProvider(my_provider)} 
                />
                <h4>Number of users in module:{users.length}</h4>
                <UsersButtons users={users} />
                <ActionButtons />
            </div>
        </div>
    )
}
