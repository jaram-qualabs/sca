import React from 'react'
import { Button } from './Button'
import { faTrash, faLightbulb, faPlus, faArrowRight } from '@fortawesome/free-solid-svg-icons'

export const ActionButtons = () => {
    return (
        <div className="action_buttons">
            < Button backgroundColor="red" title="Delete" lefticon={faTrash}/>
            < Button backgroundColor="BurlyWood" title="Advice" righticon={faLightbulb}/>
            < Button backgroundColor="LightPink" title="Create" lefticon={faPlus}/>
            < Button  backgroundColor="LightSeaGreen" title="Submit" righticon={faArrowRight}/>
        </div>
    )
}
