import React from 'react'
import { Button } from './Button'

export const UsersButtons = ({ users }) => {
    return (
        <ul className="list">
                    {
                    users.map((user)=>{
                        return <li><Button backgroundColor="purple" title={user}/></li>
                    })}
        </ul>
    )
}
