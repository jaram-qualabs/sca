import React from 'react'
import { Button } from './Button'

export const Header = ({ action, elements, buttons_color, selected }) => {
    return (
        <ul className='header'>
            { elements.map((elem)=>{
                if(selected === elem){
                    return <Button backgroundColor="Indigo" title={elem} onPress={()=> action(elem)}/>
                }
                return <Button backgroundColor={buttons_color} title={elem} onPress={()=> action(elem)}/>
            } ) }
        </ul>
    )
}
