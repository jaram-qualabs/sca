import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
export const Button = ({ title, onPress , backgroundColor , lefticon, righticon}) => {
    return (
            <button onClick={onPress} style={{backgroundColor: backgroundColor}} className='btn'>
                {lefticon && 
                <FontAwesomeIcon icon={lefticon} />
                }
                 { title } 
                 {righticon &&
                 <FontAwesomeIcon icon={righticon} />
                 }
            </button>
    )
}
