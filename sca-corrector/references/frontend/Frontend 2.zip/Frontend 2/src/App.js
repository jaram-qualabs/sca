import { Frame } from "./components/Frame";


const App = () => {
  return (
    <div className="App">
      <Frame />
    </div>
  );
}

export default App;
